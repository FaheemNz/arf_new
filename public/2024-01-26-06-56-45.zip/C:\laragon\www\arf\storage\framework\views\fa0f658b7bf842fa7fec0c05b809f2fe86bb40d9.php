<form action="<?php echo e(route('sim.import')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="file">
    <button type="submit">Import</button>
</form><?php /**PATH C:\laragon\www\arf\resources\views/import/sim.blade.php ENDPATH**/ ?>