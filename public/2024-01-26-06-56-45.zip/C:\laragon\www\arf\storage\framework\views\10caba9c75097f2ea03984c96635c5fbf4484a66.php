<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\arf\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>