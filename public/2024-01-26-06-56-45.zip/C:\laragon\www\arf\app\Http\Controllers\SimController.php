<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SimController extends Controller
{
    //
}
