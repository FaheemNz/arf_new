<?php 

    $forms = DB::Query('SELECT COUNT(*), email
    FROM arf_forms
    WHERE STATUS != \'In Active\'
    GROUP BY email
    HAVING COUNT(*) > 1');

    var_dump($forms);

?><?php /**PATH C:\laragon\www\arf\resources\views/welcome.blade.php ENDPATH**/ ?>