<?php $__env->startSection('content'); ?>

<style>
    .height {
        height: 100vh;
    }

    .form {
        position: relative;
    }

    .form .fa-search {
        position: absolute;
        top: 20px;
        left: 20px;
        color: #9ca3af;
    }

    .form span {
        position: absolute;
        right: 17px;
        top: 13px;
        padding: 2px;
        border-left: 1px solid #d1d5db;
    }

    .left-pan {
        padding-left: 7px;
    }

    .left-pan i {
        padding-left: 10px;
    }

    .form-input {
        height: 55px;
        text-indent: 33px;
        border-radius: 10px;
    }
</style>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <form action="<?php echo e(route('arfform.search')); ?>" method="GET">
                <div class="form">
                    <i class="fa fa-search"></i>
                    <input required type="text" value="<?php echo e($search_main); ?>" name="search_main" class="form-control form-input" placeholder="Enter Employee ID / Name">
                    
                </div>

                <div class="text-end mt-3">
                    <button type="button" onclick="window.location.href = '/search'" class="btn btn-outline-secondary">Refresh</button>
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </form>

            <div id="search-results" class="mt-5">
                <?php $counter = 1; ?>
                
                <?php if( isset($results) && count($results) > 0 ): ?>
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><strong>- <?php echo e($counter); ?></strong></div>
                <div class="card">
                    <div class="card-header"><?php echo e($result->name); ?></div>
                    <div class="card-body">
                        <div class="mb-3">
                            The User <strong><u>"<?php echo e($result->name); ?> (<?php echo e($result->emp_id); ?>)"</u></strong> is using following items:
                        </div>

                        <table class="table table-primary table-responsive table-bordered table-sm">
                            <thead>
                                <th>Laptop</th>
                                <th>Desktop</th>
                                <th>Monitor</th>
                                <th>Sim</th>
                                <th>Tablet</th>
                                <th>Mobile</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e(count($result->laptops)); ?></td>
                                    <td><?php echo e(count($result->desktops)); ?></td>
                                    <td><?php echo e(count($result->monitors)); ?></td>
                                    <td><?php echo e(count($result->sims)); ?></td>
                                    <td><?php echo e(count($result->tablets)); ?></td>
                                    <td><?php echo e(count($result->mobiles)); ?></td>
                                </tr>
                            </tbody>
                        </table>

                        <?php if( count($result->laptops) > 0 ): ?>
                        <h5 class="search-heading-md">Laptops</h5>
                        <table class="table table-success table-responsive table-bordered table-sm">
                            <thead>
                                <th>Asset Code</th>
                                <th>Asset Brand</th>
                                <th>Date Issued</th>
                                <th>Remarks</th>
                                <th>Status</th>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $result->laptops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_laptop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($result_laptop->asset_code); ?></td>
                                    <td><?php echo e($result_laptop->asset_brand); ?></td>
                                    <td><?php echo e($result_laptop->created_at); ?></td>
                                    <td><?php echo e($result_laptop->remarks); ?></td>
                                    <td><?php echo e($result_laptop->status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10">No Laptops</td>
                                </tr>
                                <?php endif; ?> 
                            </tbody>
                        </table>
                        <?php endif; ?>
                        
                        <?php if( count($result->desktops) > 0 ): ?>
                        <h5 class="search-heading-md">Desktops</h5>
                        <table class="table table-success table-responsive table-bordered table-sm">
                            <thead>
                                <th>Asset Code</th>
                                <th>Asset Brand</th>
                                <th>Date Issued</th>
                                <th>Remarks</th>
                                <th>Status</th>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $result->desktops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_desktop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($result_desktop->asset_code); ?></td>
                                    <td><?php echo e($result_desktop->asset_brand); ?></td>
                                    <td><?php echo e($result_desktop->created_at); ?></td>
                                    <td><?php echo e($result_desktop->remarks); ?></td>
                                    <td><?php echo e($result_desktop->status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10">No Desktops</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                        
                        <?php if( count($result->monitors) > 0 ): ?>
                        <h5 class="search-heading-md">Monitors</h5>
                        <table class="table table-success table-responsive table-bordered table-sm">
                            <thead>
                                <th>Asset Code</th>
                                <th>Asset Brand</th>
                                <th>Date Issued</th>
                                <th>Remarks</th>
                                <th>Status</th>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $result->monitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_monitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($result_monitor->asset_code); ?></td>
                                    <td><?php echo e($result_monitor->asset_brand); ?></td>
                                    <td><?php echo e($result_monitor->created_at); ?></td>
                                    <td><?php echo e($result_monitor->remarks); ?></td>
                                    <td><?php echo e($result_monitor->status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10">No Monitors</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                        
                        <?php if( count($result->tablets) > 0 ): ?>
                        <h5 class="search-heading-md">Tablets</h5>
                        <table class="table table-success table-responsive table-bordered table-sm">
                            <thead>
                                <th>Asset Code</th>
                                <th>Asset Brand</th>
                                <th>Date Issued</th>
                                <th>Remarks</th>
                                <th>Status</th>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $result->tablets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_tablet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($result_tablet->asset_code); ?></td>
                                    <td><?php echo e($result_tablet->asset_brand); ?></td>
                                    <td><?php echo e($result_tablet->created_at); ?></td>
                                    <td><?php echo e($result_tablet->remarks); ?></td>
                                    <td><?php echo e($result_tablet->status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10">No Tablets</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                        
                        <?php if( count($result->sims) > 0 ): ?>
                        <h5 class="search-heading-md">Sims</h5>
                        <table class="table table-success table-responsive table-bordered table-sm">
                            <thead>
                                <th>Asset Code</th>
                                <th>Asset Brand</th>
                                <th>Date Issued</th>
                                <th>Remarks</th>
                                <th>Status</th>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $result->sims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_sim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($result_sim->asset_code); ?></td>
                                    <td><?php echo e($result_sim->asset_brand); ?></td>
                                    <td><?php echo e($result_sim->created_at); ?></td>
                                    <td><?php echo e($result_sim->remarks); ?></td>
                                    <td><?php echo e($result_sim->status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10">No Sim</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                        
                        <?php if( count($result->mobiles) > 0 ): ?>
                        <h5 class="search-heading-md">Mobile</h5>
                        <table class="table table-success table-responsive table-bordered table-sm">
                            <thead>
                                <th>Asset Code</th>
                                <th>Asset Brand</th>
                                <th>Date Issued</th>
                                <th>Remarks</th>
                                <th>Status</th>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $result->mobiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result_mobile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($result_mobile->asset_code); ?></td>
                                    <td><?php echo e($result_mobile->asset_brand); ?></td>
                                    <td><?php echo e($result_mobile->created_at); ?></td>
                                    <td><?php echo e($result_mobile->remarks); ?></td>
                                    <td><?php echo e($result_mobile->status); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10">No Mobiles</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                </div>
                <br />
                <br />
                <?php $counter++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
    let lis = Array.from(document.getElementsByClassName('drawer-li '));

    lis.forEach(li => li.classList.remove('active'));

    document.getElementById('sideDrawerListItem4').classList.add('active');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\arf\resources\views/search.blade.php ENDPATH**/ ?>